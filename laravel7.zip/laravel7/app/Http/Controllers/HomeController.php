<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;     

use App\User;
use App\Universities;
use App\UserUniveristy;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function myuniversity(Request $req)
    {
        $Universities = Universities::all();
        $myuni = UserUniveristy::where('user_id', Auth::id())->pluck('university_id')->toArray();
        return view('myuni', ['university'=> $Universities, 'myuni'=> $myuni]);
    }

    public function submitsuni(Request $request)
    {
        $user_id = auth::user()->id;
        $uni = $request->input('myuni');
        
        UserUniveristy::where('user_id', $user_id)->delete();
        foreach ($uni as $value) {
            $uni = UserUniveristy::Create(['user_id'=> $user_id, 'university_id'=> $value]);
        }
        
        return redirect()->route('subscribe')->with('status', 'Updated!');
    }

    public function allUsers()
    {
        $result = User::with('university')->get();

        return $result->toJson();
    }


}
