<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserUniveristy extends Model
{
	protected $table = "user_university";
    protected $fillable = ['user_id', 'university_id'];
}
