<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Universities extends Model
{
     protected $table = 'universities';
}
