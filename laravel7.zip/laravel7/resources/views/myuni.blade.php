@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('My Univesity') }}</div>

                <div class="card-body">
                    <form action="{{route('submituni')}}" method="post">
                        @csrf
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        @foreach($university as $uni)
                        <div class="row">
                            <input type="checkbox" name="myuni[]" value="{{$uni->id}}"
                                @if(in_array($uni->id, $myuni)) {{ 'checked'}} @endif
                            >
                            <label> &nbsp; {{$uni->name}}</label>
                        </div>
                        @endforeach
                    </div>

                    <div>
                        <input type="submit" name="submit" value="submit" class="btn btn-primary">

                    </div>
                </form> 
                <br/><br/>
            </div>
        </div>
    </div>
</div>
@endsection
