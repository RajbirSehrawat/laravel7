<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('My Univesity')); ?></div>

                <div class="card-body">
                    <form action="<?php echo e(route('submituni')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php $__currentLoopData = $university; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <input type="checkbox" name="myuni[]" value="<?php echo e($uni->id); ?>"
                                <?php if(in_array($uni->id, $myuni)): ?> <?php echo e('checked'); ?> <?php endif; ?>
                            >
                            <label> &nbsp; <?php echo e($uni->name); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div>
                        <input type="submit" name="submit" value="submit" class="btn btn-primary">

                    </div>
                </form> 
                <br/><br/>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel7/resources/views/myuni.blade.php ENDPATH**/ ?>